package com.example.phonebook;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class MyGridLayout extends BaseAdapter {

	Context context;
	ArrayList<Integer> buttons;
	LayoutInflater inflater;
	
	
	
	public MyGridLayout(Context context, ArrayList<Integer> buttons) {
		super();
		this.context = context;
		this.buttons = buttons;
		this.inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return buttons.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return buttons.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int arg0, View arg1, ViewGroup arg2) {
		// TODO Auto-generated method stub
		ImageView iv = new ImageView(context);
		iv.setImageResource(buttons.get(arg0));
		return iv;
	}

}
