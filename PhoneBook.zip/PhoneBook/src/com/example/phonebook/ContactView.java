package com.example.phonebook;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class ContactView extends Activity implements OnItemClickListener, OnClickListener {

	ImageView iv;
	TextView lblName,lblPhone;
	GridView gv;
	MyGridLayout adapter;
	ArrayList<Integer> list = new ArrayList<Integer>();
	Uri myimage;
	String myname,myphone;
	AlertDialog g;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.viewitem_layout);
		this.iv=(ImageView) this.findViewById(R.id.imageView1);
		this.lblName=(TextView) this.findViewById(R.id.textView1);
		this.lblPhone=(TextView) this.findViewById(R.id.textView2);
		this.gv=(GridView) this.findViewById(R.id.gridView1);
		list.add(R.drawable.edit);
		list.add(R.drawable.delete);
		list.add(R.drawable.send);
		list.add(R.drawable.call);
		list.add(R.drawable.location);
		list.add(R.drawable.exit);
		this.adapter=new MyGridLayout(this,list);
		this.gv.setAdapter(adapter);
		this.gv.setOnItemClickListener(this);
		
		Bundle b = this.getIntent().getExtras();
		if(b!=null){
			myimage = b.getParcelable("image");
			myname = b.getString("name");
			myphone = b.getString("phone");
			
			this.iv.setImageURI(myimage);
			this.lblName.setText(myname);
			this.lblPhone.setText(myphone);
		}
		
		
		
	}
	
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
	
		if(resultCode==Activity.RESULT_OK){
			if(requestCode==123);
			Bundle b = this.getIntent().getExtras();
			if(b!=null){
				myimage = b.getParcelable("image");
				myname = b.getString("name");
				myphone = b.getString("phone");
				
				this.iv.setImageURI(myimage);
				this.lblName.setText(myname);
				this.lblPhone.setText(myphone);
			}
		}
	
	}



	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		switch(arg2){
		case 0:
			Intent n = new Intent(this,AddItemActivity.class);
				n.putExtra("image",myimage);
				n.putExtra("name",myname);
				n.putExtra("phone",myphone);
			this.startActivityForResult(n,123);
			break;
		case 1:
			AlertDialog.Builder ad = new AlertDialog.Builder(this);
			ad.setTitle("Delete Contact");
			ad.setMessage(String.format("Are you sure you want to delete %s ? ",myname));
			ad.setPositiveButton("Yes",this);
			ad.setNegativeButton("No", this);
			
			 g = ad.create();
			g.show();
			break;
		case 2:
			Intent in1 = new Intent(android.content.Intent.ACTION_VIEW);
			in1.putExtra("address",myphone);
			in1.putExtra("sms_body","");
			in1.setType("vnd.android-dir/mms-sms");
			this.startActivity(in1);
			break;
		case 3:
			Intent call = new Intent(Intent.ACTION_CALL,Uri.parse("tel://"+myphone));
			this.startActivity(call);
			break;
		case 4:
			break;
		case 5:
			this.finish();
			
			
			
			
			
		}
	}



	@Override
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
		switch(arg1){
		case DialogInterface.BUTTON_POSITIVE:

			//String phoneNum = list.get(info.position).getTel();
            list.remove(myphone);
           // db.deleteContact(phoneNum);
            adapter.notifyDataSetChanged();

           // Toast.makeText(this,"Deleted!", Toast.LENGTH_SHORT).show();
		case DialogInterface.BUTTON_NEGATIVE:
			g.dismiss();
		}
	}
	
}
